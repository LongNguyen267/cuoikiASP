﻿using GameStore.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace GameStore.Controllers
{
    public class ProductController : Controller
    {
        private readonly GameStoreDbContext _context;

        // Dependency Injection: DbContext sẽ được tự động cung cấp
        public ProductController(GameStoreDbContext context)
        {
            _context = context;
        }

        // Hàm này sẽ được gọi khi truy cập /Product/Index
        public async Task<IActionResult> Index()
        {
            // Lấy tất cả sản phẩm từ DB
            var products = await _context.Products.ToListAsync();
            // Gửi danh sách sản phẩm này cho View
            return View(products);
        }
    }
}