﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace GameStore.Models
{
    public class Product
    {
        [Key] // Đánh dấu đây là khóa chính
        public int ID { get; set; }

        [Required] // Bắt buộc phải có
        [StringLength(255)] // Giới hạn độ dài
        public string Name { get; set; }

        [Required]
        [StringLength(100)]
        public string SKU { get; set; }

        public string? Description { get; set; }

        [Required]
        [Column(TypeName = "decimal(18, 2)")] // Kiểu dữ liệu trong DB
        public decimal Price { get; set; }

        public int StockQuantity { get; set; }
        public string? ImageUrl { get; set; } // Sẽ dùng để lưu đường dẫn ảnh
        public string Status { get; set; }

        // Khóa ngoại tới bảng Category và Brand
        public int? CategoryID { get; set; }
        public virtual Category? Category { get; set; }

        public int? BrandID { get; set; }
        public virtual Brand? Brand { get; set; }

        public DateTime? CreatedAt { get; set; }
    }
}