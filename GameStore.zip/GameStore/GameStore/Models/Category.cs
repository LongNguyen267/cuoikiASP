﻿using System.ComponentModel.DataAnnotations;

namespace GameStore.Models
{
    public class Category
    {
        [Key]
        public int ID { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }

        // Quan hệ cha-con (tự tham chiếu)
        public int? ParentID { get; set; }
        public virtual Category? ParentCategory { get; set; }
    }
}