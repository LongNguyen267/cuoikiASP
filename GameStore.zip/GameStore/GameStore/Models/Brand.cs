﻿using System.ComponentModel.DataAnnotations;

namespace GameStore.Models
{
    public class Brand
    {
        [Key]
        public int ID { get; set; }

        [Required]
        [StringLength(100)]
        public string Name { get; set; }
    }
}