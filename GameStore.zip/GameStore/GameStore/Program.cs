﻿// Thêm các 'using' cần thiết để sử dụng các lớp từ các thư viện khác
using GameStore.Data;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllersWithViews();

builder.Services.AddDbContext<GameStoreDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

var app = builder.Build();

{
    app.UseExceptionHandler("/Home/Error");
    app.UseHsts();
}

// Tự động chuyển hướng các yêu cầu HTTP sang HTTPS để bảo mật hơn
app.UseHttpsRedirection();

app.UseStaticFiles();

app.UseRouting();

app.UseAuthorization();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}");

app.Run();
